------------
Introduction
------------

`medialog.summaryview` is a simple package that adds an option to hide content items from summary view

       
 
        
Changelog

==========
0.1 (2013.03.07)
-----------------      
- First version
